AutoAds website

Upload the contents of this folder to Netlify or another static host.
Entry point: index.html
CSS: assets/css/style.css
JavaScript: assets/js/script.js
Images: assets/images/
